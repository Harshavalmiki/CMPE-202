package com.javaip;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;

public class RequestLogHandler implements LogHandler {
    private LogHandler nextHandler;
    private Map<String, List<Integer>> responseTimesByRoute = new HashMap<>();
    private Map<String, Map<String, Integer>> statusCodesByRoute = new HashMap<>();

    @Override
    public void setNextHandler(LogHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    @Override
    public void handleLog(String logLine) {
        if (logLine.contains("request_method=")) {
            String[] parts = logLine.split(" ");
            String url = null;
            int responseTime = 0;
            String statusCode = null;
            for (String part : parts) {
                if (part.startsWith("request_url=")) {
                    url = part.substring(12);
                } else if (part.startsWith("response_time_ms=")) {
                    responseTime = Integer.parseInt(part.substring(17));
                } else if (part.startsWith("response_status=")) {
                    statusCode = part.substring(16, 19); // Assuming status codes are always three digits
                }
            }

            if (url != null) {
                responseTimesByRoute.putIfAbsent(url, new ArrayList<>());
                responseTimesByRoute.get(url).add(responseTime);

                statusCodesByRoute.putIfAbsent(url, new HashMap<>());
                String statusCodeCategory = getStatusCodeCategory(statusCode);
                statusCodesByRoute.get(url).put(statusCodeCategory, statusCodesByRoute.get(url).getOrDefault(statusCodeCategory, 0) + 1);
            }
        } else if (nextHandler != null) {
            nextHandler.handleLog(logLine);
        }
    }

    private String getStatusCodeCategory(String statusCode) {
        if (statusCode == null) {
            return "Unknown";
        }
        int code = Integer.parseInt(statusCode);
        if (code >= 200 && code < 300) {
            return "2XX";
        } else if (code >= 400 && code < 500) {
            return "4XX";
        } else if (code >= 500 && code < 600) {
            return "5XX";
        } else {
            return "Other";
        }
    }

    public Map<String, List<Integer>> getResponseTimesByRoute() {
        return responseTimesByRoute;
    }

    public Map<String, Map<String, Integer>> getStatusCodesByRoute() {
        return statusCodesByRoute;
    }

    public void writeToJson(String filename) throws IOException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("response_times", getResponseTimesMetrics());
        jsonObject.put("status_codes", getStatusCodesByRoute());

        try (FileWriter file = new FileWriter(filename)) {
            file.write(jsonObject.toString(4)); // Indented with 4 spaces
            file.flush();
        }
    }

    private JSONObject getResponseTimesMetrics() {
        JSONObject metrics = new JSONObject();
        for (Map.Entry<String, List<Integer>> entry : responseTimesByRoute.entrySet()) {
            String url = entry.getKey();
            List<Integer> responseTimes = entry.getValue();
            metrics.put(url, getResponseTimeMetrics(responseTimes));
        }
        return metrics;
    }

    private JSONObject getResponseTimeMetrics(List<Integer> responseTimes) {
        JSONObject metrics = new JSONObject();
        metrics.put("min", Collections.min(responseTimes));
        metrics.put("max", Collections.max(responseTimes));
        metrics.put("average", getAverage(responseTimes));
        metrics.put("median", getMedian(responseTimes));
        return metrics;
    }

    private double getAverage(List<Integer> numbers) {
        return numbers.stream().mapToDouble(val -> val).average().orElse(0.0);
    }

    private double getMedian(List<Integer> numbers) {
        Collections.sort(numbers);
        if (numbers.size() % 2 == 0) {
            return (numbers.get(numbers.size() / 2 - 1) + numbers.get(numbers.size() / 2)) / 2.0;
        } else {
            return numbers.get(numbers.size() / 2);
        }
    }
}