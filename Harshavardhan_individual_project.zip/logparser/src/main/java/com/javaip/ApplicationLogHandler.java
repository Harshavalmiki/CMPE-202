package com.javaip;

import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

public class ApplicationLogHandler implements LogHandler {
    private LogHandler nextHandler;
    private Map<String, Integer> logCounts = new HashMap<>();
    private int totalLogsProcessed = 0;

    @Override
    public void setNextHandler(LogHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    @Override
    public void handleLog(String logLine) {
        totalLogsProcessed++;
        if (logLine.contains("level=")) {
            String[] parts = logLine.split(" ");
            for (String part : parts) {
                if (part.startsWith("level=")) {
                    String level = part.substring(6);
                    logCounts.put(level, logCounts.getOrDefault(level, 0) + 1);
                }
            }
        } else if (nextHandler != null) {
            nextHandler.handleLog(logLine);
        }
    }

    public Map<String, Integer> getLogCounts() {
        Map<String, Integer> logCountsMap = new HashMap<>(logCounts);
        logCountsMap.put("totalLogsProcessed", totalLogsProcessed);
        // Add default values for log levels with no logs
        logCountsMap.putIfAbsent("ERROR", 0);
        logCountsMap.putIfAbsent("INFO", 0);
        logCountsMap.putIfAbsent("DEBUG", 0);
        logCountsMap.putIfAbsent("WARNING", 0);
        return logCountsMap;
    }

    public void writeToJson(String filename) throws IOException {
        Map<String, Integer> logCounts = getLogCounts();
        if (logCounts.size() == 0) {
            return; // Handle case with no logs
        }
        JSONObject jsonObject = new JSONObject(logCounts);
        try (FileWriter file = new FileWriter(filename)) {
            file.write(jsonObject.toString(4)); // Indented with 4 spaces
            file.flush();
        }
    }

    public void processAndWrite() throws IOException {
        writeToJson("application.json");
    }
}