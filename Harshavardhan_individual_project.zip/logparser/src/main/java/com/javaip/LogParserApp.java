package com.javaip;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;


public class LogParserApp {
    public static void main(String[] args) {
        Options options = new Options();
        Option input = new Option("f", "file", true, "Input log file name");
        input.setRequired(true);
        options.addOption(input);

        CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();
        CommandLine cmd;

        try {
            cmd = parser.parse(options, args);
        } catch (ParseException e) {
            System.out.println(e.getMessage());
            formatter.printHelp("utility-name", options);
            System.exit(1);
            return;
        }

        String inputFile = cmd.getOptionValue("file");
        System.out.println("Input file: " + inputFile);

        // Initialize and link handlers
        APMLogHandler apmHandler = new APMLogHandler();
        ApplicationLogHandler appHandler = new ApplicationLogHandler();
        RequestLogHandler reqHandler = new RequestLogHandler();

        apmHandler.setNextHandler(appHandler);
        appHandler.setNextHandler(reqHandler);

        // Process the log file
        processLogFile(inputFile, apmHandler);

        // Write results to JSON files
        try {
            apmHandler.writeToJson("apm.json");
            appHandler.writeToJson("application.json");
            reqHandler.writeToJson("request.json");
        } catch (IOException e) {
            System.out.println("Error writing to JSON files: " + e.getMessage());
        }
    }

    private static void processLogFile(String filePath, LogHandler handler) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                handler.handleLog(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
    }
}
