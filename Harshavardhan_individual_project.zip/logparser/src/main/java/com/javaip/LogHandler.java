package com.javaip;

public interface LogHandler {
    void setNextHandler(LogHandler nextHandler);
    void handleLog(String logLine);
}
