package com.javaip;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;

public class APMLogHandler implements LogHandler {
    private LogHandler nextHandler;
    Map<String, List<Double>> metricValues = new HashMap<>();

    @Override
    public void setNextHandler(LogHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    @Override
    public void handleLog(String logLine) {
        String[] parts = logLine.split(" ");
        String metricName = null;
        double value = 0;
        for (String part : parts) {
            if (part.startsWith("metric=")) {
                metricName = part.substring(7);
            } else if (part.startsWith("value=")) {
                value = Double.parseDouble(part.substring(6));
            }
        }
        if (metricName != null && !metricName.isEmpty() && value != 0) {
            metricValues.computeIfAbsent(metricName, k -> new ArrayList<>()).add(value);
        } else {
            // Handle non-metric log lines
            if (nextHandler != null) {
                nextHandler.handleLog(logLine);
            }
        }
    }

    public Map<String, Map<String, Double>> calculateMetrics() {
        Map<String, Map<String, Double>> results = new HashMap<>();
        for (Map.Entry<String, List<Double>> entry : metricValues.entrySet()) {
            List<Double> values = entry.getValue();
            if (values.size() == 0) {
                continue; // Handle case with no values
            }
            Collections.sort(values);
            double min = values.get(0);
            double max = values.get(values.size() - 1);
            double median;
            if (values.size() == 1) {
                median = values.get(0); // Handle case with only one value
            } else if (values.size() % 2 == 0) {
                median = (values.get(values.size() / 2 - 1) + values.get(values.size() / 2)) / 2;
            } else {
                median = values.get(values.size() / 2);
            }
            double average = values.stream().mapToDouble(val -> val).average().orElse(0.0);
    
            Map<String, Double> metrics = new HashMap<>();
            metrics.put("min", min); // Changed from "minimum" to "min"
            metrics.put("median", median); // Changed from "median" to "median" (no change needed)
            metrics.put("avg", average); // Changed from "average" to "avg"
            metrics.put("max", max); // Changed from "max" to "max" (no change needed)
            results.put(entry.getKey(), metrics);
        }
        return results;
    }

    public void writeToJson(String filename) throws IOException {
        Map<String, Map<String, Double>> metrics = calculateMetrics();
        if (metrics.size() == 0) {
            return; // Handle case with no metrics
        }
        JSONObject jsonObject = new JSONObject(metrics);
        try (FileWriter file = new FileWriter(filename)) {
            file.write(jsonObject.toString(4)); // Indented with 4 spaces
            file.flush();
        }
    }
}