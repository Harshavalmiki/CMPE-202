package com.javaip;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.junit.jupiter.api.Test;

public class RequestLogHandlerTest {
    @Test
    void testHandleLog() {
        RequestLogHandler handler = new RequestLogHandler();
        handler.handleLog("request_method=GET request_url=/users response_time_ms=100 response_status=200");
        handler.handleLog("request_method=GET request_url=/users response_time_ms=200 response_status=200");
        handler.handleLog("request_method=GET request_url=/products response_time_ms=50 response_status=404");

        Map<String, List<Integer>> responseTimesByRoute = handler.getResponseTimesByRoute();
        assertEquals(2, responseTimesByRoute.size());
        assertTrue(responseTimesByRoute.containsKey("/users"));
        assertTrue(responseTimesByRoute.containsKey("/products"));
        assertEquals(2, responseTimesByRoute.get("/users").size());
        assertEquals(1, responseTimesByRoute.get("/products").size());

        Map<String, Map<String, Integer>> statusCodesByRoute = handler.getStatusCodesByRoute();
        assertEquals(2, statusCodesByRoute.size());
        assertTrue(statusCodesByRoute.containsKey("/users"));
        assertTrue(statusCodesByRoute.containsKey("/products"));
        assertEquals(1, statusCodesByRoute.get("/users").size());
        assertEquals(1, statusCodesByRoute.get("/products").size());
    }

    @Test
    void testWriteToJson() throws IOException {
        RequestLogHandler handler = new RequestLogHandler();
        handler.handleLog("request_method=GET request_url=/users response_time_ms=100 response_status=200");
        handler.handleLog("request_method=GET request_url=/users response_time_ms=200 response_status=200");
        handler.handleLog("request_method=GET request_url=/products response_time_ms=50 response_status=404");

        String filename = "requestlogs.json";
        handler.writeToJson(filename);

        File file = new File(filename);
        assertTrue(file.exists());

        String content = new String(Files.readAllBytes(Paths.get(filename)));
        JSONObject jsonObject = new JSONObject(content);
        assertEquals(2, jsonObject.keySet().size());
        assertTrue(jsonObject.has("response_times"));
        assertTrue(jsonObject.has("status_codes"));

        JSONObject responseTimesJsonObject = jsonObject.getJSONObject("response_times");
        assertEquals(2, responseTimesJsonObject.keySet().size());
        assertTrue(responseTimesJsonObject.has("/users"));
        assertTrue(responseTimesJsonObject.has("/products"));

        JSONObject statusCodesJsonObject = jsonObject.getJSONObject("status_codes");
        assertEquals(2, statusCodesJsonObject.keySet().size());
        assertTrue(statusCodesJsonObject.has("/users"));
        assertTrue(statusCodesJsonObject.has("/products"));

    }
}