package com.javaip;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.junit.jupiter.api.Test;

public class APMLogHandlerTest {
    @Test
    void testHandleLog() {
        APMLogHandler handler = new APMLogHandler();
        handler.handleLog("metric=ResponseTime value=100");
        handler.handleLog("metric=ResponseTime value=200");
        handler.handleLog("metric=ErrorRate value=0.5");

        Map<String, List<Double>> metricValues = handler.metricValues;
        assertEquals(2, metricValues.size());
        assertTrue(metricValues.containsKey("ResponseTime"));
        assertTrue(metricValues.containsKey("ErrorRate"));
        assertEquals(2, metricValues.get("ResponseTime").size());
        assertEquals(1, metricValues.get("ErrorRate").size());
    }

    @Test
    void testCalculateMetrics() {
        APMLogHandler handler = new APMLogHandler();
        handler.handleLog("metric=ResponseTime value=100");
        handler.handleLog("metric=ResponseTime value=200");
        handler.handleLog("metric=ErrorRate value=0.5");

        Map<String, Map<String, Double>> metrics = handler.calculateMetrics();
        assertEquals(2, metrics.size());
        assertTrue(metrics.containsKey("ResponseTime"));
        assertTrue(metrics.containsKey("ErrorRate"));

        Map<String, Double> responseTimeMetrics = metrics.get("ResponseTime");
        assertEquals(100.0, responseTimeMetrics.get("min"));
        assertEquals(150.0, responseTimeMetrics.get("median"));
        assertEquals(150.0, responseTimeMetrics.get("avg"));
        assertEquals(200.0, responseTimeMetrics.get("max"));

        Map<String, Double> errorRateMetrics = metrics.get("ErrorRate");
        assertEquals(0.5, errorRateMetrics.get("min"));
        assertEquals(0.5, errorRateMetrics.get("median"));
        assertEquals(0.5, errorRateMetrics.get("avg"));
        assertEquals(0.5, errorRateMetrics.get("max"));
    }

    @Test
    void testWriteToJson() throws IOException {
        APMLogHandler handler = new APMLogHandler();
        handler.handleLog("metric=ResponseTime value=100");
        handler.handleLog("metric=ResponseTime value=200");
        handler.handleLog("metric=ErrorRate value=0.5");

        String filename = "metrics.json";
        handler.writeToJson(filename);

        File file = new File(filename);
        assertTrue(file.exists());

        String content = new String(Files.readAllBytes(Paths.get(filename)));
        JSONObject jsonObject = new JSONObject(content);
        assertEquals(2, jsonObject.keySet().size());
        assertTrue(jsonObject.has("ResponseTime"));
        assertTrue(jsonObject.has("ErrorRate"));

        JSONObject responseTimeMetrics = jsonObject.getJSONObject("ResponseTime");
        assertEquals(100.0, responseTimeMetrics.getDouble("min"));
        assertEquals(150.0, responseTimeMetrics.getDouble("median"));
        assertEquals(150.0, responseTimeMetrics.getDouble("avg"));
        assertEquals(200.0, responseTimeMetrics.getDouble("max"));

        JSONObject errorRateMetrics = jsonObject.getJSONObject("ErrorRate");
        assertEquals(0.5, errorRateMetrics.getDouble("min"));
        assertEquals(0.5, errorRateMetrics.getDouble("median"));
        assertEquals(0.5, errorRateMetrics.getDouble("avg"));
        assertEquals(0.5, errorRateMetrics.getDouble("max"));

    }
}