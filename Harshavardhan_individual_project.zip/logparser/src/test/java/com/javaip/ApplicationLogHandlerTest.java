package com.javaip;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

import org.json.JSONObject;
import org.junit.jupiter.api.Test;

public class ApplicationLogHandlerTest {
    @Test
void testHandleLog() {
    ApplicationLogHandler handler = new ApplicationLogHandler();
    handler.handleLog("level=INFO message=Hello");
    handler.handleLog("level=ERROR message=Something went wrong");
    handler.handleLog("level=INFO message=Goodbye");

    Map<String, Integer> logCounts = handler.getLogCounts();
    assertEquals(5, logCounts.size()); // Update the expected value
    assertTrue(logCounts.containsKey("INFO"));
    assertTrue(logCounts.containsKey("ERROR"));
    assertEquals(2, logCounts.get("INFO").intValue());
    assertEquals(1, logCounts.get("ERROR").intValue());
}

@Test
void testWriteToJson() throws IOException {
    ApplicationLogHandler handler = new ApplicationLogHandler();
    handler.handleLog("level=INFO message=Hello");
    handler.handleLog("level=ERROR message=Something went wrong");
    handler.handleLog("level=INFO message=Goodbye");

    String filename = "logcounts.json";
    handler.writeToJson(filename);

    File file = new File(filename);
    assertTrue(file.exists());

    String content = new String(Files.readAllBytes(Paths.get(filename)));
    JSONObject jsonObject = new JSONObject(content);
    assertEquals(5, jsonObject.keySet().size()); // Update the expected value
    assertTrue(jsonObject.has("INFO"));
    assertTrue(jsonObject.has("ERROR"));
    assertEquals(2, jsonObject.getInt("INFO"));
    assertEquals(1, jsonObject.getInt("ERROR"));


}

}